package mocks

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"log"
	http "net/http"
	"testing"
	"webclient/restclient"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

var url = "http://localhost:5572"

// func init() {
// 	restclient.Client = &HTTPClient{}
// }

func TestTestMock(t *testing.T) {
	mc := HTTPClient{}
	restclient.Client = &mc
	json := `{"Status":"Test Name","full_name":"test full name","owner":{"login": "octocat"}}`
	r := ioutil.NopCloser(bytes.NewReader([]byte(json)))

	mockresp := &http.Response{
		StatusCode: 200,
		Status:     "200 OK",
		Body:       r,
	}

	mc.On("Do", mock.Anything).Return(mockresp, nil).Once()
	method := url + "/rc/version"
	resp, err := restclient.PostMessage(method, "", nil)
	if err != nil {
		log.Fatal(err)
	}
	assert.Equal(t, resp.StatusCode, 200)
	assert.Equal(t, resp.Status, "200 OK")
}

func TestTestMockFailed(t *testing.T) {
	mc := HTTPClient{}
	restclient.Client = &mc
	mockresp := &http.Response{StatusCode: 400, Status: "400 Bad request"}
	mc.On("Do", mock.Anything).Return(mockresp, nil).Once()
	method := url + "/rc/version"
	resp, err := restclient.PostMessage(method, "", nil)
	if err != nil {
		log.Fatal(err)
	}
	assert.Equal(t, resp.StatusCode, 400)
	assert.Equal(t, resp.Status, "400 Bad request")
}

func TestTestMockInternalError(t *testing.T) {
	mc := HTTPClient{}
	restclient.Client = &mc
	// mockresp := &http.Response{StatusCode: 400, Status: "400 Bad request"}
	mockresp := &http.Response{
		StatusCode: 500,
		Status:     "Bad request",
		Body:       ioutil.NopCloser(bytes.NewBufferString(`Internal Error`)),
		Header:     make(http.Header),
	}
	mc.On("Do", mock.Anything).Return(mockresp, nil).Once()
	method := url + "/rc/version"
	resp, err := restclient.PostMessage(method, "", nil)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
	responseData, err := ioutil.ReadAll(resp.Body)
	assert.Nil(t, err)
	responseString := string(responseData)
	fmt.Println(responseString)
	fmt.Println("Response status:", resp.Status)
	fmt.Println("Response status:", resp.StatusCode)
}
