package main

import (
	"fmt"
	"log"
	"webclient/restclient"
)

var url = "http://localhost:5572"

func main() {
	fmt.Println("Hellow")
	method := url + "/rc/version"
	resp, err := restclient.PostMessage(method, "", nil)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
}
