# Testify Maintainers

The individuals listed below are active in the project and have the ability to approve and merge
pull requests.

  * @glesica
  * @boyan-soubachov
  * @mvdkleijn

