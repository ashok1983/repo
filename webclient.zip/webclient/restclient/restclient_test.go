package restclient

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"reflect"
	"testing"

	"github.com/stretchr/testify/assert"
)

var (
	url     = "http://localhost:5572"
	postUrl = "http://localhost:5572"
)
var (
	result = `{
	"version": "v1.2.3-egnyte"
}
`
)

func TestTestRcloneGetVersion(t *testing.T) {
	method := url + "/rc/version"
	resp, err := PostMessage(method, "", nil)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
	responseData, err := ioutil.ReadAll(resp.Body)
	assert.Nil(t, err)
	responseString := string(responseData)
	fmt.Println(responseString)
	assert.Equal(t, result, responseString)
}

func TestTestRcloneCoreStats(t *testing.T) {
	method := url + "/core/stats"
	resp, err := PostMessage(method, "", nil)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
	responseData, err := ioutil.ReadAll(resp.Body)
	assert.Nil(t, err)
	responseString := string(responseData)
	fmt.Println(responseString)
	fmt.Println("Response status:", resp.Status)
}

func TestPostMessage(t *testing.T) {
	type args struct {
		url     string
		body    interface{}
		headers http.Header
	}
	r := ioutil.NopCloser(bytes.NewReader([]byte(result)))
	tests := []struct {
		name    string
		args    args
		want    *http.Response
		wantErr bool
	}{
		{
			name: "test-version",
			args: args{
				url:     postUrl + "/rc/version",
				body:    "",
				headers: nil,
			},
			want:    &http.Response{StatusCode: 200, Body: r},
			wantErr: false,
		},
		{
			name: "test-stats",
			args: args{
				url:     postUrl + "/core/stats",
				body:    "",
				headers: nil,
			},
			want:    &http.Response{StatusCode: 200, Body: r},
			wantErr: false,
		},
		{
			name: "test-ping",
			args: args{
				url:     postUrl + "/rc/ping",
				body:    "",
				headers: nil,
			},
			want:    &http.Response{StatusCode: 200, Body: r},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := PostMessage(tt.args.url, tt.args.body, tt.args.headers)
			if (err != nil) != tt.wantErr {
				t.Errorf("PostMessage() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got.StatusCode, tt.want.StatusCode) {
				t.Errorf("PostMessage() = %d, want %d", got.StatusCode, tt.want.StatusCode)
			}
			responseData, err := ioutil.ReadAll(got.Body)
			assert.Nil(t, err)
			responseString := string(responseData)
			fmt.Println(responseString)
		})
	}
}
